from app import add_admin, add_student

if __name__ == "__main__":
    # Add sample admin and student (passwords will be hashed)
    add_admin('admin', 'adminpass')
    add_student(1, 'Rahul', '123', 'rahul@gmail.com')
    print("Setup complete")
