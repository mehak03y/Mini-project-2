from flask import Flask, render_template, request, redirect, session, jsonify
import sqlite3
import random
from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-change-in-production')

# Email config (CHANGE THESE)
app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT', 587))
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME', 'your_email@gmail.com')
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD', 'your_app_password')
app.config['MAIL_USE_TLS'] = True

mail = Mail(app)

def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()

    cur.execute("CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, name TEXT, password TEXT, voted INTEGER DEFAULT 0, email TEXT)")
    cur.execute("CREATE TABLE IF NOT EXISTS candidates(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)")
    cur.execute("CREATE TABLE IF NOT EXISTS votes(student_id INTEGER, candidate_id INTEGER, FOREIGN KEY(student_id) REFERENCES students(id), FOREIGN KEY(candidate_id) REFERENCES candidates(id))")
    cur.execute("CREATE TABLE IF NOT EXISTS admin(username TEXT PRIMARY KEY, password TEXT)")

    conn.commit()
    conn.close()

init_db()

# IMPORTANT: Use this to add admin users with hashed passwords
def add_admin(username, password):
    """Add admin user with hashed password"""
    try:
        conn = get_db()
        cur = conn.cursor()
        hashed_pwd = generate_password_hash(password)
        cur.execute("INSERT OR REPLACE INTO admin(username, password) VALUES (?, ?)", (username, hashed_pwd))
        conn.commit()
        conn.close()
        print(f"Admin '{username}' added successfully")
    except Exception as e:
        print(f"Error adding admin: {e}")

# IMPORTANT: Use this to add student users with hashed passwords
def add_student(student_id, name, password, email):
    """Add student user with hashed password"""
    try:
        conn = get_db()
        cur = conn.cursor()
        hashed_pwd = generate_password_hash(password)
        cur.execute("INSERT INTO students(id, name, password, email) VALUES (?, ?, ?, ?)", (student_id, name, hashed_pwd, email))
        conn.commit()
        conn.close()
        print(f"Student '{student_id}' added successfully")
    except Exception as e:
        print(f"Error adding student: {e}")

@app.route('/')
def login():
    return render_template("login.html")

@app.route('/login', methods=['POST'])
def login_user():
    try:
        identifier = request.form.get('student_id', '').strip()
        password = request.form.get('password', '').strip()

        if not identifier or not password:
            return render_template('login.html', error='Student ID (or email/name) and password required'), 400

        conn = get_db()
        cur = conn.cursor()

        user = None
        # Try numeric ID first
        if identifier.isdigit():
            cur.execute("SELECT * FROM students WHERE id=?", (int(identifier),))
            user = cur.fetchone()

        # Try email
        if not user:
            cur.execute("SELECT * FROM students WHERE email=?", (identifier,))
            user = cur.fetchone()

        # Try exact name
        if not user:
            cur.execute("SELECT * FROM students WHERE name=?", (identifier,))
            user = cur.fetchone()

        conn.close()

        if user and check_password_hash(user['password'], password):
            otp = random.randint(100000, 999999)
            session['otp'] = otp
            session['student_id'] = str(user['id'])

            msg = Message("Voting OTP", sender=app.config['MAIL_USERNAME'], recipients=[user['email']])
            msg.body = f"Your OTP is {otp}. Do not share this with anyone."
            try:
                mail.send(msg)
            except Exception as mail_err:
                if os.environ.get('DEV_SHOW_OTP', '').lower() in ('1', 'true', 'yes'):
                    print(f"Warning: mail.send failed: {mail_err}")
                    print(f"OTP for student {user['id']}: {otp}")
                else:
                    app.logger.warning(f"mail.send failed: {mail_err}")

            return redirect('/verify_otp')

        # Render login page with an error message instead of plain text
        return render_template('login.html', error='Invalid student ID/email/name or password'), 401
    except Exception as e:
        app.logger.exception('Login error')
        return render_template('login.html', error='An unexpected error occurred'), 500

@app.route('/verify_otp')
def verify_page():
    return render_template("otp.html")

@app.route('/verify', methods=['POST'])
def verify():
    try:
        otp_input = request.form.get('otp', '')
        if not otp_input or not otp_input.isdigit():
            return "Invalid OTP format", 400

        if int(otp_input) == session.get('otp'):
            # Clear OTP after successful verification
            session.pop('otp', None)
            return redirect('/vote/' + session['student_id'])
        return "Invalid OTP", 401
    except Exception as e:
        return f"Verification error: {str(e)}", 500

@app.route('/vote/<student_id>')
def vote(student_id):
    # Validate session matches URL parameter
    if student_id != session.get('student_id'):
        return "Unauthorized", 403
    
    try:
        conn = get_db()
        cur = conn.cursor()
        
        # Check if student already voted
        cur.execute("SELECT voted FROM students WHERE id=?", (student_id,))
        student = cur.fetchone()
        if student and student['voted']:
            conn.close()
            return "You have already voted", 403
        
        cur.execute("SELECT * FROM candidates")
        candidates = cur.fetchall()
        conn.close()
        return render_template("vote.html", candidates=candidates, student_id=student_id)
    except Exception as e:
        return f"Error: {str(e)}", 500

@app.route('/submit_vote', methods=['POST'])
def submit_vote():
    try:
        student_id = request.form.get('student_id', '').strip()
        candidate_id = request.form.get('candidate', '').strip()
        
        # Validate session and parameters
        if student_id != session.get('student_id'):
            return "Unauthorized", 403
        
        if not student_id or not candidate_id:
            return "Missing required fields", 400
        
        try:
            candidate_id = int(candidate_id)
        except ValueError:
            return "Invalid candidate ID", 400

        conn = get_db()
        cur = conn.cursor()
        
        # Check if student already voted
        cur.execute("SELECT voted FROM students WHERE id=?", (student_id,))
        student = cur.fetchone()
        if not student or student['voted']:
            conn.close()
            return "You have already voted", 403
        
        # Validate candidate exists
        cur.execute("SELECT id FROM candidates WHERE id=?", (candidate_id,))
        if not cur.fetchone():
            conn.close()
            return "Invalid candidate", 400
        
        cur.execute("INSERT INTO votes(student_id, candidate_id) VALUES (?,?)", (student_id, candidate_id))
        cur.execute("UPDATE students SET voted=1 WHERE id=?", (student_id,))
        conn.commit()
        conn.close()
        
        # Clear session data
        session.pop('student_id', None)
        
        return redirect("/results")
    except Exception as e:
        return f"Error submitting vote: {str(e)}", 500

@app.route('/results')
def results():
    try:
        conn = get_db()
        cur = conn.cursor()

        # Aggregate vote counts by candidate_id using SQL
        cur.execute("SELECT candidate_id, COUNT(*) as votes FROM votes GROUP BY candidate_id")
        rows = cur.fetchall()

        if not rows:
            conn.close()
            return render_template("result.html", result={})

        result = {}
        total = 0
        for r in rows:
            cid = r['candidate_id']
            votes = r['votes']
            total += votes
            cur.execute("SELECT name FROM candidates WHERE id=?", (cid,))
            candidate = cur.fetchone()
            name = candidate['name'] if candidate else f"Candidate {cid}"
            result[name] = votes

        conn.close()
        return render_template("result.html", result=result)
    except Exception as e:
        return f"Error retrieving results: {str(e)}", 500

@app.route('/admin')
def admin_login():
    return render_template("admin_login.html")

@app.route('/admin_login', methods=['POST'])
def admin_auth():
    try:
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        if not username or not password:
            return "Username and password required", 400

        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM admin WHERE username=?", (username,))
        admin = cur.fetchone()
        conn.close()

        if admin and check_password_hash(admin['password'], password):
            session['admin'] = username
            return redirect("/admin_dashboard")

        return "Invalid Admin Login", 401
    except Exception as e:
        return f"Login error: {str(e)}", 500

@app.route('/admin_dashboard')
def admin_dashboard():
    if 'admin' not in session:
        return redirect('/admin')
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM candidates")
        candidates = cur.fetchall()
        conn.close()

        return render_template("admin_dashboard.html", candidates=candidates)
    except Exception as e:
        return f"Error: {str(e)}", 500

@app.route('/add_candidate', methods=['GET','POST'])
def add_candidate():
    if 'admin' not in session:
        return redirect('/admin')
    
    if request.method == 'POST':
        try:
            name = request.form.get('name', '').strip()
            if not name or len(name) < 2:
                return "Candidate name must be at least 2 characters", 400
            
            conn = get_db()
            cur = conn.cursor()
            cur.execute("INSERT INTO candidates(name) VALUES (?)", (name,))
            conn.commit()
            conn.close()
            return redirect('/admin_dashboard')
        except Exception as e:
            return f"Error adding candidate: {str(e)}", 500

    return render_template("add_candidate.html")

@app.route('/delete_candidate/<int:id>')
def delete_candidate(id):
    if 'admin' not in session:
        return redirect('/admin')
    
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("DELETE FROM candidates WHERE id=?", (id,))
        conn.commit()
        conn.close()
        return redirect('/admin_dashboard')
    except Exception as e:
        return f"Error deleting candidate: {str(e)}", 500

@app.route('/admin_logout')
def admin_logout():
    session.pop('admin', None)
    return redirect('/admin')


@app.route('/_dev_otp')
def dev_otp():
    """Development helper: return the OTP stored in the current session.
    Only available when the environment variable DEV_SHOW_OTP is enabled.
    """
    if os.environ.get('DEV_SHOW_OTP', '').lower() not in ('1', 'true', 'yes'):
        return "Not allowed", 403
    otp = session.get('otp')
    if otp is None:
        return "No OTP in session", 404
    return jsonify({"otp": otp})


# NOTE: removed debug-only `/ _dev_otp` endpoint. To enable OTP console
# printing for local testing set the environment variable:
# DEV_SHOW_OTP=1

if __name__ == "__main__":
    app.run(debug=True)
