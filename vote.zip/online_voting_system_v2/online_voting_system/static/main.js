/**
 * VoteSecure — Main JS v2
 * Particles · OTP Boxes · Form UX · Modals · Result Bars
 */

/* ─── Particle Canvas ─────────────────────────────────────── */
(function initParticles() {
  const canvas = document.createElement('canvas');
  canvas.id = 'particle-canvas';
  document.body.prepend(canvas);
  const ctx = canvas.getContext('2d');

  const COLORS = ['#5468ff', '#0dc5b0', '#3a4fd7', '#5ef0e0'];
  const PARTICLE_COUNT = 55;
  const particles = [];

  function resize() {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  class Particle {
    constructor() { this.reset(true); }
    reset(init = false) {
      this.x  = Math.random() * canvas.width;
      this.y  = init ? Math.random() * canvas.height : canvas.height + 20;
      this.r  = Math.random() * 1.8 + 0.4;
      this.vx = (Math.random() - 0.5) * 0.3;
      this.vy = -(Math.random() * 0.5 + 0.2);
      this.alpha = Math.random() * 0.5 + 0.1;
      this.color = COLORS[Math.floor(Math.random() * COLORS.length)];
      this.pulse = Math.random() * Math.PI * 2;
    }
    update() {
      this.x += this.vx;
      this.y += this.vy;
      this.pulse += 0.02;
      this.alpha = (Math.sin(this.pulse) * 0.2 + 0.3);
      if (this.y < -20) this.reset();
    }
    draw() {
      ctx.save();
      ctx.globalAlpha = this.alpha;
      ctx.fillStyle = this.color;
      ctx.shadowBlur = 6;
      ctx.shadowColor = this.color;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  // Connection lines between nearby particles
  function drawConnections() {
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 100) {
          ctx.save();
          ctx.globalAlpha = (1 - dist / 100) * 0.06;
          ctx.strokeStyle = '#5468ff';
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
          ctx.restore();
        }
      }
    }
  }

  for (let i = 0; i < PARTICLE_COUNT; i++) particles.push(new Particle());

  function loop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawConnections();
    particles.forEach(p => { p.update(); p.draw(); });
    requestAnimationFrame(loop);
  }
  loop();
})();


/* ─── Staggered Card Entrance ─────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  const items = document.querySelectorAll('.card, .stat-box, .candidate-card, .result-item');
  items.forEach((el, i) => {
    el.style.animationDelay = `${i * 0.07}s`;
  });
});


/* ─── OTP Box UX ──────────────────────────────────────────── */
(function initOTPBoxes() {
  const group = document.querySelector('.otp-box-group');
  if (!group) return;

  const boxes = group.querySelectorAll('.otp-box');
  const hidden = document.querySelector('.otp-hidden');

  function syncHidden() {
    if (!hidden) return;
    hidden.value = Array.from(boxes).map(b => b.value).join('');
  }

  boxes.forEach((box, idx) => {
    box.addEventListener('input', e => {
      const val = e.target.value.replace(/\D/g, '');
      box.value = val.slice(-1);
      if (val) {
        box.classList.add('filled');
        if (idx < boxes.length - 1) boxes[idx + 1].focus();
      } else {
        box.classList.remove('filled');
      }
      syncHidden();
    });

    box.addEventListener('keydown', e => {
      if (e.key === 'Backspace' && !box.value && idx > 0) {
        boxes[idx - 1].focus();
        boxes[idx - 1].value = '';
        boxes[idx - 1].classList.remove('filled');
        syncHidden();
      }
      // Allow paste on any box
      if (e.key === 'v' && (e.ctrlKey || e.metaKey)) return;
    });

    box.addEventListener('paste', e => {
      e.preventDefault();
      const pasted = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
      boxes.forEach((b, i) => {
        b.value = pasted[i] || '';
        b.classList.toggle('filled', !!b.value);
      });
      syncHidden();
      const nextEmpty = Array.from(boxes).findIndex(b => !b.value);
      (boxes[nextEmpty] || boxes[boxes.length - 1]).focus();
    });

    // Allow only digits
    box.addEventListener('keypress', e => {
      if (!/[0-9]/.test(e.key)) e.preventDefault();
    });
  });

  // Auto-focus first box
  if (boxes[0]) boxes[0].focus();
})();


/* ─── Candidate Card Selection ─────────────────────────────── */
(function initCandidateCards() {
  const cards = document.querySelectorAll('.candidate-card');
  cards.forEach(card => {
    card.addEventListener('click', () => {
      cards.forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      const radio = card.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;

      // Ripple
      const ripple = document.createElement('span');
      ripple.style.cssText = `
        position:absolute;border-radius:50%;
        background:rgba(84,104,255,0.2);
        width:10px;height:10px;
        transform:scale(0);
        animation:rippleOut 0.6s ease-out forwards;
        left:50%;top:50%;margin:-5px;
        pointer-events:none;
      `;
      card.appendChild(ripple);
      setTimeout(() => ripple.remove(), 700);
    });
  });

  // Inject ripple keyframe
  if (!document.getElementById('ripple-style')) {
    const s = document.createElement('style');
    s.id = 'ripple-style';
    s.textContent = '@keyframes rippleOut{to{transform:scale(30);opacity:0;}}';
    document.head.appendChild(s);
  }
})();


/* ─── Vote Confirm Modal ─────────────────────────────────────── */
window.openVoteModal = function() {
  const checked = document.querySelector('.candidate-card.selected input[type="radio"]');
  if (!checked) {
    showToast('Please select a candidate first', 'warn');
    return;
  }
  const name = checked.closest('.candidate-card').querySelector('.candidate-name').textContent;
  const el = document.getElementById('modal-selected-name');
  if (el) el.textContent = name;
  const backdrop = document.getElementById('voteModal');
  if (backdrop) backdrop.classList.add('open');
};

window.closeVoteModal = function() {
  const backdrop = document.getElementById('voteModal');
  if (backdrop) backdrop.classList.remove('open');
};

window.submitVoteForm = function() {
  const form = document.getElementById('voteForm');
  if (form) {
    const btn = document.querySelector('#voteModal .btn-primary');
    if (btn) btn.classList.add('loading');
    form.submit();
  }
};

// Close on backdrop click
document.addEventListener('click', e => {
  if (e.target.id === 'voteModal') closeVoteModal();
});


/* ─── Delete Confirm Modal ───────────────────────────────────── */
window.confirmDelete = function(id, name) {
  const el = document.getElementById('delete-name');
  if (el) el.textContent = name;
  const backdrop = document.getElementById('deleteModal');
  if (backdrop) {
    backdrop.classList.add('open');
    backdrop.dataset.deleteId = id;
  }
};

window.closeDeleteModal = function() {
  const backdrop = document.getElementById('deleteModal');
  if (backdrop) backdrop.classList.remove('open');
};

window.executeDelete = function() {
  const backdrop = document.getElementById('deleteModal');
  if (backdrop && backdrop.dataset.deleteId) {
    window.location.href = `/delete_candidate/${backdrop.dataset.deleteId}`;
  }
};


/* ─── Animated Result Bars ─────────────────────────────────── */
(function animateBars() {
  const bars = document.querySelectorAll('.bar-fill[data-pct]');
  if (!bars.length) return;

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const bar = entry.target;
        const pct = bar.dataset.pct;
        setTimeout(() => { bar.style.width = pct + '%'; }, 200);
        observer.unobserve(bar);
      }
    });
  }, { threshold: 0.3 });

  bars.forEach(bar => observer.observe(bar));
})();


/* ─── Form Submit Loading ──────────────────────────────────── */
document.querySelectorAll('form').forEach(form => {
  form.addEventListener('submit', () => {
    const btn = form.querySelector('.btn-primary');
    if (btn) btn.classList.add('loading');
  });
});


/* ─── Toast Notification ─────────────────────────────────── */
window.showToast = function(msg, type = 'info') {
  const existing = document.querySelector('.vs-toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  const colors = {
    info: 'rgba(84,104,255,0.95)',
    warn: 'rgba(255,180,0,0.95)',
    ok:   'rgba(34,209,126,0.95)',
    error:'rgba(255,90,90,0.95)',
  };
  toast.className = 'vs-toast';
  toast.textContent = msg;
  toast.style.cssText = `
    position:fixed; bottom:2rem; left:50%; transform:translateX(-50%) translateY(20px);
    background:${colors[type]||colors.info};
    color:white; padding:0.75rem 1.5rem;
    border-radius:12px; font-family:'Syne',sans-serif;
    font-size:0.85rem; font-weight:600;
    box-shadow:0 8px 30px rgba(0,0,0,0.3);
    z-index:9999; opacity:0;
    transition: all 0.3s cubic-bezier(0.23,1,0.32,1);
    white-space:nowrap;
  `;
  document.body.appendChild(toast);
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';
  });
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-50%) translateY(20px)';
    setTimeout(() => toast.remove(), 400);
  }, 3000);
};


/* ─── Input Focus Floating Label ─────────────────────────── */
document.querySelectorAll('.form-group input').forEach(input => {
  input.addEventListener('focus', () => {
    input.closest('.form-group')?.classList.add('focused');
  });
  input.addEventListener('blur', () => {
    input.closest('.form-group')?.classList.remove('focused');
  });
});


/* ─── Live Clock for Dashboard ───────────────────────────── */
const clockEl = document.getElementById('live-clock');
if (clockEl) {
  function updateClock() {
    const now = new Date();
    clockEl.textContent = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }
  updateClock();
  setInterval(updateClock, 1000);
}
