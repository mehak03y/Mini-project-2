import requests, sqlite3, re, sys

BASE = 'http://127.0.0.1:5000'

s = requests.Session()
print('POST /login')
r = s.post(BASE + '/login', data={'student_id': '1', 'password': '123'})
print('login status', r.status_code, 'url', r.url)

print('\nGET /_dev_otp')
r = s.get(BASE + '/_dev_otp')
print('otp response', r.status_code, r.text)
try:
    otp = r.json().get('otp')
except Exception:
    m = re.search(r'"otp":\s*([0-9]+)', r.text)
    otp = m.group(1) if m else None
print('otp ->', otp)
if not otp:
    print('No OTP found, aborting')
    sys.exit(1)

print('\nPOST /verify')
r = s.post(BASE + '/verify', data={'otp': str(otp)})
print('verify status', r.status_code, 'url', r.url)

# Ensure candidate exists
conn = sqlite3.connect('database.db')
conn.row_factory = sqlite3.Row
cur = conn.cursor()
cur.execute("SELECT id FROM candidates LIMIT 1")
row = cur.fetchone()
if row:
    cid = row['id']
    print('using existing candidate', cid)
else:
    cur.execute("INSERT INTO candidates(name) VALUES (?)", ('Candidate 1',))
    conn.commit()
    cid = cur.lastrowid
    print('inserted candidate', cid)
conn.close()

print('\nPOST /submit_vote')
r = s.post(BASE + '/submit_vote', data={'student_id': '1', 'candidate': str(cid)})
print('submit_vote status', r.status_code, 'url', r.url)

print('\nGET /results')
r = s.get(BASE + '/results')
print('results status', r.status_code)
print(r.text[:800])

# Inspect DB votes
conn = sqlite3.connect('database.db')
conn.row_factory = sqlite3.Row
cur = conn.cursor()
cur.execute('SELECT * FROM votes')
rows = cur.fetchall()
print('\nVotes in DB:')
for r in rows:
    print(dict(r))
conn.close()
