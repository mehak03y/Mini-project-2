"""
Setup script to initialize test users and admin
Run this once to populate the database with test data
"""

from app import add_admin, add_student

# Add admin user
print("Adding admin user...")
add_admin('admin', 'admin123')

# Add test students
print("\nAdding test students...")
test_students = [
    ('1', 'Rahul', 'password123', 'rahul@gmail.com'),
    ('2', 'Priya', 'password123', 'priya@gmail.com'),
    ('3', 'Amit', 'password123', 'amit@gmail.com'),
    ('4', 'Sarah', 'password123', 'sarah@gmail.com'),
    ('5', 'John', 'password123', 'john@gmail.com'),
]

for student_id, name, password, email in test_students:
    add_student(student_id, name, password, email)

print("\n✅ Database setup complete!")
print("\nTest Credentials:")
print("=" * 40)
print("Admin Login:")
print("  Username: admin")
print("  Password: admin123")
print("\nStudent Login:")
print("  Student ID: 1, 2, 3, 4, or 5")
print("  Password: password123")
print("=" * 40)
